/* =========================================================
   STUDENT ATTENDANCE MANAGEMENT SYSTEM
   DATABASE MANAGEMENT SYSTEM PROJECT
   ========================================================= */

/* =========================================================
   1. CREATE DATABASE
   ========================================================= */

CREATE DATABASE Student_Attendance_DB;

USE Student_Attendance_DB;


/* =========================================================
   2. DEPARTMENT TABLE
   ========================================================= */

CREATE TABLE Department (
    Department_ID INT PRIMARY KEY AUTO_INCREMENT,
    Department_Name VARCHAR(100) NOT NULL UNIQUE,
    Description VARCHAR(255)
);


/* =========================================================
   3. CLASS TABLE
   ========================================================= */

CREATE TABLE Class (
    Class_ID INT PRIMARY KEY AUTO_INCREMENT,
    Section VARCHAR(20) NOT NULL,
    Year INT NOT NULL,
    Department_ID INT NOT NULL,

    CONSTRAINT fk_class_department
        FOREIGN KEY (Department_ID)
        REFERENCES Department(Department_ID),

    CONSTRAINT chk_class_year
        CHECK (Year BETWEEN 1 AND 4),

    CONSTRAINT uq_class
        UNIQUE (Section, Year, Department_ID)
);


/* =========================================================
   4. STUDENT TABLE
   ========================================================= */

CREATE TABLE Student (
    Student_ID INT PRIMARY KEY AUTO_INCREMENT,
    Student_Name VARCHAR(100) NOT NULL,
    Roll_Number VARCHAR(20) NOT NULL UNIQUE,
    Email VARCHAR(100) UNIQUE,
    Phone VARCHAR(15),
    Class_ID INT NOT NULL,
    Department_ID INT NOT NULL,

    CONSTRAINT fk_student_class
        FOREIGN KEY (Class_ID)
        REFERENCES Class(Class_ID),

    CONSTRAINT fk_student_department
        FOREIGN KEY (Department_ID)
        REFERENCES Department(Department_ID)
);


/* =========================================================
   5. FACULTY TABLE
   ========================================================= */

CREATE TABLE Faculty (
    Faculty_ID INT PRIMARY KEY AUTO_INCREMENT,
    Faculty_Name VARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE,
    Phone VARCHAR(15),
    Department_ID INT NOT NULL,

    CONSTRAINT fk_faculty_department
        FOREIGN KEY (Department_ID)
        REFERENCES Department(Department_ID)
);


/* =========================================================
   6. SUBJECT TABLE
   ========================================================= */

CREATE TABLE Subject (
    Subject_ID INT PRIMARY KEY AUTO_INCREMENT,
    Subject_Name VARCHAR(100) NOT NULL,
    Credits INT NOT NULL,
    Faculty_ID INT NOT NULL,

    CONSTRAINT fk_subject_faculty
        FOREIGN KEY (Faculty_ID)
        REFERENCES Faculty(Faculty_ID),

    CONSTRAINT chk_subject_credits
        CHECK (Credits BETWEEN 1 AND 6)
);


/* =========================================================
   7. ATTENDANCE TABLE
   ========================================================= */

CREATE TABLE Attendance (
    Attendance_ID INT PRIMARY KEY AUTO_INCREMENT,
    Student_ID INT NOT NULL,
    Subject_ID INT NOT NULL,
    Attendance_Date DATE NOT NULL,
    Status ENUM('Present', 'Absent') NOT NULL,

    CONSTRAINT fk_attendance_student
        FOREIGN KEY (Student_ID)
        REFERENCES Student(Student_ID),

    CONSTRAINT fk_attendance_subject
        FOREIGN KEY (Subject_ID)
        REFERENCES Subject(Subject_ID),

    /* A student can have only one attendance record
       for a particular subject on a particular date */
    CONSTRAINT uq_attendance
        UNIQUE (Student_ID, Subject_ID, Attendance_Date)
);


/* =========================================================
   8. INSERT DEPARTMENTS
   ========================================================= */

INSERT INTO Department
(Department_Name, Description)
VALUES
('Artificial Intelligence and Machine Learning',
 'Department of Artificial Intelligence and Machine Learning'),

('Computer Science and Engineering',
 'Department of Computer Science and Engineering'),

('Electronics and Communication Engineering',
 'Department of Electronics and Communication Engineering');


/* =========================================================
   9. INSERT CLASSES
   ========================================================= */

INSERT INTO Class
(Section, Year, Department_ID)
VALUES
('A', 1, 1),
('B', 1, 1),
('A', 2, 1),
('A', 1, 2),
('A', 1, 3);


/* =========================================================
   10. INSERT STUDENTS
   ========================================================= */

INSERT INTO Student
(Student_Name, Roll_Number, Email, Phone, Class_ID, Department_ID)
VALUES
('Harsha Vardhan Reddy',
 '25B11AI887',
 'harsha@gmail.com',
 '9876543210',
 1,
 1),

('Manikanta',
 '25B11AI141',
 'manikanta@gmail.com',
 '9876543211',
 1,
 1),

('Rohith',
 '25B11AI338',
 'rohith@gmail.com',
 '9876543212',
 1,
 1),

('Varaprasad',
 '25B11AI127',
 'varaprasad@gmail.com',
 '9876543213',
 1,
 1),

('Keerthi',
 '25B11AI544',
 'keerthi@gmail.com',
 '9876543214',
 2,
 1),

('Rahul',
 '25B11AI501',
 'rahul@gmail.com',
 '9876543215',
 3,
 1),

('Sneha',
 '25B11AI502',
 'sneha@gmail.com',
 '9876543216',
 4,
 2);


/* =========================================================
   11. INSERT FACULTY
   ========================================================= */

INSERT INTO Faculty
(Faculty_Name, Email, Phone, Department_ID)
VALUES
('Mrs. Pravallika',
 'pravallika@adityauniversity.in',
 '9000000001',
 1),

('Dr. Ramesh',
 'ramesh@adityauniversity.in',
 '9000000002',
 1),

('Ms. Keerthi',
 'keerthi@adityauniversity.in',
 '9000000003',
 2);


/* =========================================================
   12. INSERT SUBJECTS
   ========================================================= */

INSERT INTO Subject
(Subject_Name, Credits, Faculty_ID)
VALUES
('Database Management Systems', 4, 1),
('Python Programming', 4, 2),
('Data Structures', 4, 1),
('Computer Networks', 3, 3),
('Machine Learning', 4, 2);


/* =========================================================
   13. INSERT ATTENDANCE
   ========================================================= */

INSERT INTO Attendance
(Student_ID, Subject_ID, Attendance_Date, Status)
VALUES

/* Harsha */
(1, 1, '2026-09-01', 'Present'),
(1, 2, '2026-09-01', 'Present'),
(1, 3, '2026-09-01', 'Absent'),
(1, 1, '2026-09-02', 'Present'),
(1, 2, '2026-09-02', 'Present'),
(1, 3, '2026-09-02', 'Present'),

/* Manikanta */
(2, 1, '2026-09-01', 'Present'),
(2, 2, '2026-09-01', 'Absent'),
(2, 3, '2026-09-01', 'Present'),
(2, 1, '2026-09-02', 'Present'),
(2, 2, '2026-09-02', 'Present'),
(2, 3, '2026-09-02', 'Present'),

/* Rohith */
(3, 1, '2026-09-01', 'Absent'),
(3, 2, '2026-09-01', 'Present'),
(3, 3, '2026-09-01', 'Present'),
(3, 1, '2026-09-02', 'Present'),
(3, 2, '2026-09-02', 'Present'),
(3, 3, '2026-09-02', 'Absent'),

/* Varaprasad */
(4, 1, '2026-09-01', 'Present'),
(4, 2, '2026-09-01', 'Present'),
(4, 3, '2026-09-01', 'Present'),
(4, 1, '2026-09-02', 'Present'),
(4, 2, '2026-09-02', 'Absent'),
(4, 3, '2026-09-02', 'Present'),

/* Keerthi */
(5, 1, '2026-09-01', 'Absent'),
(5, 2, '2026-09-01', 'Present'),
(5, 3, '2026-09-01', 'Present');


/* =========================================================
   14. DISPLAY ALL TABLES
   ========================================================= */

SELECT * FROM Department;

SELECT * FROM Class;

SELECT * FROM Student;

SELECT * FROM Faculty;

SELECT * FROM Subject;

SELECT * FROM Attendance;


/* =========================================================
   15. BASIC DQL QUERIES
   ========================================================= */

/* Display all students */

SELECT *
FROM Student;


/* Display only student names and roll numbers */

SELECT Student_Name, Roll_Number
FROM Student;


/* Display students from AIML */

SELECT Student_Name, Roll_Number
FROM Student
WHERE Department_ID = 1;


/* Display students alphabetically */

SELECT Student_Name, Roll_Number
FROM Student
ORDER BY Student_Name ASC;


/* Display students whose name starts with H */

SELECT *
FROM Student
WHERE Student_Name LIKE 'H%';


/* =========================================================
   16. UPDATE OPERATION
   ========================================================= */

UPDATE Student
SET Phone = '9999999999'
WHERE Student_ID = 1;


/* Check updated record */

SELECT *
FROM Student
WHERE Student_ID = 1;


/* =========================================================
   17. DELETE OPERATION
   ========================================================= */

/*
   Example:
   DELETE FROM Student
   WHERE Student_ID = 7;
*/


/* =========================================================
   18. INNER JOIN
   ========================================================= */

SELECT
    s.Student_ID,
    s.Student_Name,
    s.Roll_Number,
    d.Department_Name
FROM Student s
INNER JOIN Department d
ON s.Department_ID = d.Department_ID;


/* =========================================================
   19. STUDENT + CLASS JOIN
   ========================================================= */

SELECT
    s.Student_Name,
    s.Roll_Number,
    c.Section,
    c.Year
FROM Student s
INNER JOIN Class c
ON s.Class_ID = c.Class_ID;


/* =========================================================
   20. STUDENT + ATTENDANCE + SUBJECT
   ========================================================= */

SELECT
    s.Student_Name,
    s.Roll_Number,
    sub.Subject_Name,
    a.Attendance_Date,
    a.Status
FROM Student s
INNER JOIN Attendance a
ON s.Student_ID = a.Student_ID
INNER JOIN Subject sub
ON a.Subject_ID = sub.Subject_ID
ORDER BY s.Student_Name, a.Attendance_Date;


/* =========================================================
   21. STUDENT + SUBJECT + FACULTY
   ========================================================= */

SELECT
    s.Student_Name,
    sub.Subject_Name,
    f.Faculty_Name
FROM Student s
JOIN Attendance a
ON s.Student_ID = a.Student_ID
JOIN Subject sub
ON a.Subject_ID = sub.Subject_ID
JOIN Faculty f
ON sub.Faculty_ID = f.Faculty_ID;


/* =========================================================
   22. LEFT JOIN
   ========================================================= */

SELECT
    s.Student_Name,
    a.Attendance_Date,
    a.Status
FROM Student s
LEFT JOIN Attendance a
ON s.Student_ID = a.Student_ID
ORDER BY s.Student_Name;


/* =========================================================
   23. RIGHT JOIN
   ========================================================= */

SELECT
    s.Student_Name,
    a.Attendance_Date,
    a.Status
FROM Student s
RIGHT JOIN Attendance a
ON s.Student_ID = a.Student_ID;


/* =========================================================
   24. GROUP BY
   ========================================================= */

/* Number of students in each department */

SELECT
    d.Department_Name,
    COUNT(s.Student_ID) AS Total_Students
FROM Department d
LEFT JOIN Student s
ON d.Department_ID = s.Department_ID
GROUP BY d.Department_ID, d.Department_Name;


/* =========================================================
   25. COUNT PRESENT AND ABSENT
   ========================================================= */

SELECT
    Status,
    COUNT(*) AS Total
FROM Attendance
GROUP BY Status;


/* =========================================================
   26. ATTENDANCE PERCENTAGE FOR EACH STUDENT
   ========================================================= */

SELECT
    s.Student_ID,
    s.Student_Name,

    COUNT(a.Attendance_ID) AS Total_Classes,

    SUM(
        CASE
            WHEN a.Status = 'Present' THEN 1
            ELSE 0
        END
    ) AS Present_Classes,

    ROUND(
        SUM(
            CASE
                WHEN a.Status = 'Present' THEN 1
                ELSE 0
            END
        ) * 100.0 / COUNT(a.Attendance_ID),
        2
    ) AS Attendance_Percentage

FROM Student s
LEFT JOIN Attendance a
ON s.Student_ID = a.Student_ID

GROUP BY
    s.Student_ID,
    s.Student_Name;


/* =========================================================
   27. SUBJECT-WISE ATTENDANCE
   ========================================================= */

SELECT
    sub.Subject_Name,

    COUNT(a.Attendance_ID) AS Total_Classes,

    SUM(
        CASE
            WHEN a.Status = 'Present'
            THEN 1
            ELSE 0
        END
    ) AS Present_Count,

    ROUND(
        SUM(
            CASE
                WHEN a.Status = 'Present'
                THEN 1
                ELSE 0
            END
        ) * 100.0 / COUNT(a.Attendance_ID),
        2
    ) AS Attendance_Percentage

FROM Subject sub

LEFT JOIN Attendance a
ON sub.Subject_ID = a.Subject_ID

GROUP BY
    sub.Subject_ID,
    sub.Subject_Name;


/* =========================================================
   28. STUDENTS BELOW 75% ATTENDANCE
   ========================================================= */

SELECT
    s.Student_ID,
    s.Student_Name,

    ROUND(
        SUM(
            CASE
                WHEN a.Status = 'Present'
                THEN 1
                ELSE 0
            END
        ) * 100.0 / COUNT(a.Attendance_ID),
        2
    ) AS Attendance_Percentage

FROM Student s

JOIN Attendance a
ON s.Student_ID = a.Student_ID

GROUP BY
    s.Student_ID,
    s.Student_Name

HAVING Attendance_Percentage < 75;


/* =========================================================
   29. VIEW - COMPLETE ATTENDANCE
   ========================================================= */

CREATE VIEW Student_Attendance_View AS

SELECT
    s.Student_ID,
    s.Student_Name,
    s.Roll_Number,
    sub.Subject_Name,
    a.Attendance_Date,
    a.Status

FROM Student s

JOIN Attendance a
ON s.Student_ID = a.Student_ID

JOIN Subject sub
ON a.Subject_ID = sub.Subject_ID;


/* Display View */

SELECT *
FROM Student_Attendance_View;


/* =========================================================
   30. VIEW - ATTENDANCE PERCENTAGE
   ========================================================= */

CREATE VIEW Attendance_Percentage_View AS

SELECT
    s.Student_ID,
    s.Student_Name,
    s.Roll_Number,

    COUNT(a.Attendance_ID) AS Total_Classes,

    SUM(
        CASE
            WHEN a.Status = 'Present'
            THEN 1
            ELSE 0
        END
    ) AS Present_Classes,

    SUM(
        CASE
            WHEN a.Status = 'Absent'
            THEN 1
            ELSE 0
        END
    ) AS Absent_Classes,

    ROUND(
        SUM(
            CASE
                WHEN a.Status = 'Present'
                THEN 1
                ELSE 0
            END
        ) * 100.0 / COUNT(a.Attendance_ID),
        2
    ) AS Attendance_Percentage

FROM Student s

LEFT JOIN Attendance a
ON s.Student_ID = a.Student_ID

GROUP BY
    s.Student_ID,
    s.Student_Name,
    s.Roll_Number;


/* Display Attendance Percentage */

SELECT *
FROM Attendance_Percentage_View;


/* =========================================================
   31. SEARCH PARTICULAR STUDENT
   ========================================================= */

SELECT *
FROM Student
WHERE Roll_Number = '25B11AI887';


/* =========================================================
   32. HARSHAVARDHAN REDDY ATTENDANCE
   ========================================================= */

SELECT
    s.Student_Name,
    s.Roll_Number,
    sub.Subject_Name,
    a.Attendance_Date,
    a.Status

FROM Student s

JOIN Attendance a
ON s.Student_ID = a.Student_ID

JOIN Subject sub
ON a.Subject_ID = sub.Subject_ID

WHERE s.Roll_Number = '25B11AI887'

ORDER BY a.Attendance_Date;


/* =========================================================
   33. DATE-WISE ATTENDANCE
   ========================================================= */

SELECT
    a.Attendance_Date,
    COUNT(*) AS Total_Records,

    SUM(
        CASE
            WHEN a.Status = 'Present'
            THEN 1
            ELSE 0
        END
    ) AS Present,

    SUM(
        CASE
            WHEN a.Status = 'Absent'
            THEN 1
            ELSE 0
        END
    ) AS Absent

FROM Attendance a

GROUP BY a.Attendance_Date

ORDER BY a.Attendance_Date;


/* =========================================================
   34. FACULTY-SUBJECT DETAILS
   ========================================================= */

SELECT
    f.Faculty_Name,
    sub.Subject_Name,
    sub.Credits

FROM Faculty f

JOIN Subject sub
ON f.Faculty_ID = sub.Faculty_ID;


/* =========================================================
   35. DEPARTMENT-WISE STUDENT COUNT
   ========================================================= */

SELECT
    d.Department_Name,
    COUNT(s.Student_ID) AS Total_Students

FROM Department d

LEFT JOIN Student s
ON d.Department_ID = s.Department_ID

GROUP BY
    d.Department_ID,
    d.Department_Name

ORDER BY Total_Students DESC;


/* =========================================================
   36. SUBJECT-WISE PRESENT COUNT
   ========================================================= */

SELECT
    sub.Subject_Name,
    COUNT(a.Attendance_ID) AS Present_Count

FROM Subject sub

JOIN Attendance a
ON sub.Subject_ID = a.Subject_ID

WHERE a.Status = 'Present'

GROUP BY
    sub.Subject_ID,
    sub.Subject_Name;


/* =========================================================
   37. HAVING CLAUSE
   ========================================================= */

SELECT
    Student_ID,
    COUNT(*) AS Total_Attendance

FROM Attendance

GROUP BY Student_ID

HAVING COUNT(*) >= 3;


/* =========================================================
   38. ORDER BY ATTENDANCE PERCENTAGE
   ========================================================= */

SELECT *
FROM Attendance_Percentage_View
ORDER BY Attendance_Percentage DESC;


/* =========================================================
   39. TRANSACTION - ACID PROPERTY DEMONSTRATION
   ========================================================= */

START TRANSACTION;

INSERT INTO Attendance
(Student_ID, Subject_ID, Attendance_Date, Status)
VALUES
(1, 1, '2026-09-03', 'Present');

COMMIT;


/* =========================================================
   40. ROLLBACK DEMONSTRATION
   ========================================================= */

START TRANSACTION;

INSERT INTO Attendance
(Student_ID, Subject_ID, Attendance_Date, Status)
VALUES
(2, 1, '2026-09-03', 'Absent');

/* Cancel the transaction */

ROLLBACK;


/* =========================================================
   41. CHECK AFTER ROLLBACK
   ========================================================= */

SELECT *
FROM Attendance
WHERE Student_ID = 2
AND Attendance_Date = '2026-09-03';


/* =========================================================
   42. ALTER TABLE - DDL DEMONSTRATION
   ========================================================= */

/*
ALTER TABLE Student
ADD Date_Of_Birth DATE;
*/


/* =========================================================
   43. CREATE INDEX
   ========================================================= */

CREATE INDEX idx_student_name
ON Student(Student_Name);


/* =========================================================
   44. FINAL DATABASE CHECK
   ========================================================= */

SHOW TABLES;

SELECT COUNT(*) AS Total_Students
FROM Student;

SELECT COUNT(*) AS Total_Faculty
FROM Faculty;

SELECT COUNT(*) AS Total_Subjects
FROM Subject;

SELECT COUNT(*) AS Total_Attendance_Records
FROM Attendance;